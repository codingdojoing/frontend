# bower-the-guide-styles

This repo is for distribution on `bower`. The source for this module is in the
[main TheGuideStyles repo](https://stash.europe.intranet/projects/TG/repos/theguidestyles/browse).

Documentation is available on http://theguide.europe.intranet/