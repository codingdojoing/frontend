Welcome to spectINGular-dependencies. SpectINGular-dependencies takes care of managing which versions should be used for building spectINGular stuff.
