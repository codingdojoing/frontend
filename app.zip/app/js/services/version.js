'use strict';

/* Version service */
angular.module('xbrlImport').
factory('version', function () {
    return {
        version: '1.0.0-SNAPSHOT'
    };
});
